MSG.myBlocks = "我的積木";
MSG.myCategory1 = "目錄 1";
MSG.myCategory2 = "目錄 2";