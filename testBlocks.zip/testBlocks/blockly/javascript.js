Blockly.JavaScript['sayhello'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = 'alert("大家好")';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};
