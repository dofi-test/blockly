Blockly.Blocks['sayhello'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("打招呼");
    this.setOutput(true, null);
    this.setColour(230);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};